# Hammer.js 2.0 [![Build Status](https://travis-ci.org/hammerjs/hammer.js.svg)](https://travis-ci.org/hammerjs/hammer.js/)

Visit [hammerjs.github.io](http://hammerjs.github.io) for documentation.

You can get the pre-build versions from the Hammer.js website, or do this by yourself running 
`npm install -g grunt-cli && npm install && grunt build`
