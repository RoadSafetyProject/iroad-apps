require('./angular-animate');

module.exports = angular-animate;
