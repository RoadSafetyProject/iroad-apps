require('./angular-aria');

module.exports = angular-aria;
